"""Unit tests for the memory graph manager."""

from __future__ import annotations

import json
from pathlib import Path

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import unittest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from zdownloadmanager.core.memory_graph_manager import build_graph_from_context


class MemoryGraphTestCase(unittest.TestCase):
    """Tests for the memory graph builder."""

    def test_build_graph_from_context(self) -> None:
        import json
        from tempfile import TemporaryDirectory

        data = {
            "dependencies": {
                "a.py": ["b.py"],
                "b.py": [],
            }
        }
        with TemporaryDirectory() as tmpdir:
            ctx = Path(tmpdir) / "context_snapshot.json"
            ctx.write_text(json.dumps(data), encoding="utf-8")
            graph = build_graph_from_context(ctx)
            # Two nodes should be created
            self.assertEqual(len(graph.nodes), 2)
            # Version should be bumped from the default
            self.assertNotEqual(graph.version, "0.00")
            # There should be an edge from a.py to b.py
            mapping = {node.content: nid for nid, node in graph.nodes.items()}
            a_id = mapping["a.py"]
            b_id = mapping["b.py"]
            self.assertIn(b_id, graph.nodes[a_id].edges.get("imports", set()))