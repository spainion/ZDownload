"""Test snapshot generation utilities."""

from __future__ import annotations

from pathlib import Path
import json

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import unittest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from zamida_helpers_v0_02 import update_snapshots


class UpdateSnapshotsTestCase(unittest.TestCase):
    """Tests for snapshot regeneration helpers."""

    def test_update_snapshots(self) -> None:
        import json
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            # Create a minimal project with one Python file and one Markdown file
            py_file = tmp_path / "example.py"
            py_file.write_text("def foo():\n    return 1\n", encoding="utf-8")
            md_file = tmp_path / "README.md"
            md_file.write_text("# Example\nThis is a test.\n", encoding="utf-8")
            # Generate snapshots
            update_snapshots(tmp_path)
            # Check that snapshot files exist
            ctx_md = tmp_path / "context_snapshot.md"
            ctx_json = tmp_path / "context_snapshot.json"
            code_md = tmp_path / "code_snapshot.md"
            code_json = tmp_path / "code_snapshot.json"
            self.assertTrue(ctx_md.exists())
            self.assertTrue(ctx_json.exists())
            self.assertTrue(code_md.exists())
            self.assertTrue(code_json.exists())
            # Validate JSON structure
            data = json.loads(ctx_json.read_text(encoding="utf-8"))
            self.assertIn("files", data)
            self.assertIn("dependencies", data)