"""Tests for the plugin manager."""

from __future__ import annotations

from pathlib import Path
import sys

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import unittest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from zdownloadmanager.core.plugin_manager import load_plugins


class PluginManagerTestCase(unittest.TestCase):
    """Tests for the plugin manager."""

    def test_load_plugins(self) -> None:
        from tempfile import TemporaryDirectory
        # Create a temporary directory structure with a plugins directory
        with TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            plugins_dir = tmp_path / "plugins"
            plugins_dir.mkdir(parents=True, exist_ok=True)
            # Create a simple plugin that sets a flag when registered
            plugin_file = plugins_dir / "myplugin.py"
            plugin_code = (
                "registered = {'value': False}\n"
                "def register():\n"
                "    registered['value'] = True\n"
                "def on_start():\n"
                "    return 'started'\n"
            )
            plugin_file.write_text(plugin_code, encoding="utf-8")
            # Ensure our tmp_path is on sys.path for import
            if str(tmp_path) not in sys.path:
                sys.path.insert(0, str(tmp_path))
            modules = load_plugins(tmp_path)
            # Exactly one plugin should load
            self.assertEqual(len(modules), 1)
            mod = modules[0]
            # The register() function should have set the flag to True
            self.assertTrue(getattr(mod, "registered")["value"])
            # The plugin should expose the on_start hook in plugin_hooks
            from zdownloadmanager.core.plugin_manager import plugin_hooks
            self.assertIn("on_start", plugin_hooks)
            self.assertIn(mod.on_start, plugin_hooks["on_start"])