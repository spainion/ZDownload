import unittest
import sys
from pathlib import Path

# Ensure the backup_manager module can be imported from the project root
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import backup_manager


class BackupManagerTestCase(unittest.TestCase):
    """Tests for the backup manager utility."""

    def test_create_backup(self) -> None:
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            # Create a temporary project structure
            project_dir = tmp_path / "project"
            project_dir.mkdir()
            (project_dir / "README.md").write_text("test", encoding="utf-8")
            # Run backup
            output_dir = tmp_path / "backups"
            backup_path = backup_manager.create_backup(project_dir, output_dir, max_backups=3)
            self.assertTrue(backup_path.exists())