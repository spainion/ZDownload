"""Tests for graph analysis utilities in memory_graph_manager."""

import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from zdownloadmanager.core.memory_graph_manager import (
    MemoryGraph,
    compute_strongly_connected_components,
    find_most_dependent_nodes,
)


class GraphAnalysisTestCase(unittest.TestCase):
    def test_sccs_and_inbound_counts(self) -> None:
        # Build a graph with a cycle: a -> b -> c -> a and one isolated node d
        g = MemoryGraph()
        a = g.add_node("a.py")
        b = g.add_node("b.py")
        c = g.add_node("c.py")
        d = g.add_node("d.py")
        # Add edges to form a cycle among a, b, c
        g.link_nodes(a.id, "imports", b.id)
        g.link_nodes(b.id, "imports", c.id)
        g.link_nodes(c.id, "imports", a.id)
        # Add a dependency on a from d
        g.link_nodes(d.id, "imports", a.id)
        # Compute SCCs
        sccs = compute_strongly_connected_components(g)
        # There should be two components: one cycle of size 3 and one singleton
        scc_sizes = sorted([len(c) for c in sccs])
        self.assertEqual(scc_sizes, [1, 3])
        # Find most dependent nodes
        top = find_most_dependent_nodes(g, top_n=2)
        # Node 'a' should have highest inbound count (from c and d)
        # Map node id to content
        id_to_content = {nid: g.nodes[nid].content for nid in g.nodes}
        most_dependent_id, count = top[0]
        self.assertEqual(id_to_content[most_dependent_id], "a.py")
        self.assertEqual(count, 2)