#!/bin/sh
# Initialise the development environment by printing documentation,
# installing dependencies and generating context/code snapshots. This
# script mirrors the upstream project's init.sh for consistency.
set -e
# Load API keys from a keys.txt file if present.  This optional step
# extracts secret tokens and exports them as environment variables.  The
# `keys.txt` file should contain lines like "ChatGPT full access account
# key:" and "Open router API key:" followed by the corresponding token on
# the next line.  Keys are trimmed of whitespace.  Use this only in
# development; do not commit `keys.txt` into your repository.
if [ -f "keys.txt" ]; then
  # Extract ChatGPT / OpenAI key (used for OpenAI API)
  key_line=$(grep -n "ChatGPT full access account key" keys.txt | cut -d: -f1 || true)
  if [ -n "$key_line" ]; then
    # The token is on the next line
    key_val=$(sed -n "$((key_line + 1))p" keys.txt | tr -d '\r\n ')
    [ -n "$key_val" ] && export OPENAI_API_KEY="$key_val"
  fi
  # Extract OpenRouter key
  or_line=$(grep -n "Open router API key" keys.txt | cut -d: -f1 || true)
  if [ -n "$or_line" ]; then
    or_val=$(sed -n "$((or_line + 1))p" keys.txt | tr -d '\r\n ')
    [ -n "$or_val" ] && export OPENROUTER_API_KEY="$or_val"
  fi
  # Extract GitHub token (use the first occurrence)
  gh_line=$(grep -n "GitHub full access account key" keys.txt | cut -d: -f1 || true)
  if [ -n "$gh_line" ]; then
    gh_val=$(sed -n "$((gh_line + 1))p" keys.txt | tr -d '\r\n ')
    [ -n "$gh_val" ] && export GITHUB_TOKEN="$gh_val"
  fi
fi
# Display all Markdown files to aid agent ingestion
find . -name '*.md' -print | while read -r file; do
  printf '\n===== %s =====\n' "$file"
  cat "$file"
done
# Install Python dependencies
pip install -r requirements.txt
# Install pre-commit hooks if available (ignore failures silently)
pre-commit install >/dev/null 2>&1 || true
# Generate initial context and code snapshots
python scripts/context_snapshot.py >/dev/null 2>&1 || true
python scripts/code_scan.py >/dev/null 2>&1 || true

# Enable network by default.  Users can override this by setting
# NETWORK_ENABLED=0 before sourcing this script.  The setting is
# consumed by the configuration system to decide whether to perform
# outbound API calls and web scraping.
if [ -z "$NETWORK_ENABLED" ]; then
  export NETWORK_ENABLED=1
fi