"""
ZDownloadManager Backup Utility
================================

This script provides a bullet‑proof backup routine for your ZDownloadManager
project.  It creates timestamped archives of the entire project directory,
optionally including version information, and stores them in a dedicated
backup folder.  Each backup uses a unique name to avoid overwriting
previous snapshots and can be executed as part of your development workflow
to preserve important state before changes.

Usage
-----
Run this script from the root of your ZDownloadManager project to create a
backup of the current directory.  You can customise the target project
directory and output location via command‑line arguments.

Example:

```
python backup_manager.py --project-dir . --output-dir backups
```

This will generate a ZIP archive named something like
`ZDownloadManager_v0.14_20250830_154830.zip` in the `backups` folder.

Implementation Notes
--------------------
- The version string is read from the README.md file by searching for
  the first occurrence of `ZDownloadManager` followed by a version.
- Archives are created using `shutil.make_archive`, which preserves the
  directory structure.  Files in the backup output directory are excluded
  to prevent recursive archives.
- Environment variables for API keys are not accessed here; backup
  functionality is independent of network credentials.

Future Enhancements
-------------------
- Introduce incremental/differential backups to reduce archive size.
- Upload backups to a remote storage service for offsite redundancy.

"""

import argparse
import datetime
import os
import re
import shutil
from pathlib import Path


def get_project_version(project_dir: Path) -> str:
    """Extract the project version from the README.md file.

    If a version cannot be determined, returns ``"unknown"``.

    Parameters
    ----------
    project_dir : Path
        The root directory of the project.

    Returns
    -------
    str
        The parsed version string (e.g. ``"v0.14"``) or ``"unknown"``.
    """
    readme_path = project_dir / "README.md"
    if not readme_path.exists():
        return "unknown"
    pattern = re.compile(r"ZDownloadManager\s*v([0-9]+\.[0-9]+(?:\.[0-9]+)?)", re.IGNORECASE)
    try:
        with readme_path.open("r", encoding="utf-8") as f:
            for line in f:
                match = pattern.search(line)
                if match:
                    return f"v{match.group(1)}"
    except Exception:
        pass
    return "unknown"


def create_backup(project_dir: Path, output_dir: Path, *, max_backups: int | None = None) -> Path:
    """Create a zipped backup of the project directory.

    The resulting archive will be named using the pattern
    ``ZDownloadManager_<version>_<timestamp>.zip`` and placed in
    ``output_dir``.  Files inside ``output_dir`` are excluded from the
    archive.

    Parameters
    ----------
    project_dir : Path
        The directory to back up.
    output_dir : Path
        The directory where backups should be stored.

    Returns
    -------
    Path
        The full path to the created backup archive.
    """
    version = get_project_version(project_dir)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_name = f"ZDownloadManager_{version}_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=True)
    archive_path = output_dir / f"{archive_name}.zip"

    # Create the archive using a temporary path to avoid including output_dir itself
    temp_archive_root = project_dir.parent / archive_name
    # Always clean up the temporary directory, even if copying or archiving fails
    try:
        if temp_archive_root.exists():
            shutil.rmtree(temp_archive_root)
        shutil.copytree(project_dir, temp_archive_root)
        # Remove backups directory from the copy to avoid nested archives
        backup_subdir = temp_archive_root / output_dir.name
        if backup_subdir.exists():
            shutil.rmtree(backup_subdir)
        # Create the zip archive from the temporary copy
        shutil.make_archive(base_name=str(output_dir / archive_name), format="zip", root_dir=temp_archive_root)
    finally:
        # Clean up the temporary copy
        if temp_archive_root.exists():
            shutil.rmtree(temp_archive_root)
    # If a maximum number of backups is specified, prune older backups
    if max_backups is not None:
        # List existing zip archives sorted by modification time ascending
        backups = sorted((f for f in output_dir.glob("ZDownloadManager_*.zip") if f.is_file()), key=lambda p: p.stat().st_mtime)
        # Remove oldest backups if exceeding max_backups
        while len(backups) > max_backups:
            old = backups.pop(0)
            try:
                old.unlink()
            except OSError:
                pass
    return archive_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a backup of the ZDownloadManager project.")
    parser.add_argument(
        "--project-dir",
        type=Path,
        default=Path("."),
        help="Path to the ZDownloadManager project to back up (default: current directory)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("backups"),
        help="Directory where backup archives will be stored (default: backups)",
    )
    parser.add_argument(
        "--max-backups",
        type=int,
        default=None,
        help="Maximum number of backup archives to retain; older ones will be deleted (default: keep all)",
    )
    args = parser.parse_args()
    backup_path = create_backup(
        args.project_dir.resolve(), args.output_dir.resolve(), max_backups=args.max_backups
    )
    print(f"Backup created: {backup_path}")


if __name__ == "__main__":
    main()