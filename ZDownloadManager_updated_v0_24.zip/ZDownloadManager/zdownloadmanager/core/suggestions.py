"""Integration with OpenRouter to provide file suggestions.

This module offers a simple wrapper around the OpenRouter chat completion
endpoint. It is used to retrieve contextual information about files (e.g.
descriptions of programs) by asking an AI model. The API key and whether
suggestions should be enabled are configured in ``Config``. If the key is
missing or suggestions are disabled, the functions return ``None``.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, Dict, List, Generator

import requests

from .config import Config

# Predefined catalogue of models supported on OpenRouter along with their
# estimated cost per million tokens and approximate context window size.
# The cost values are derived from publicly available information and
# represent the combined input and output cost for one million tokens.
# Context is measured in tokens. Free models have zero cost. This list can
# be extended as new models become available or pricing changes.
_MODEL_CATALOGUE: List[Dict[str, float | str]] = [
    {
        "name": "google/gemini-flash",  # experimental free variant
        "input_cost": 0.0,
        "output_cost": 0.0,
        "context": 1_048_576,
    },
    {
        "name": "deepseek/deepseek-chat",  # free chat model (DeepSeek V3)
        "input_cost": 0.0,
        "output_cost": 0.0,
        "context": 163_840,
    },
    {
        "name": "mistral/mistral-medium",  # budget general‑purpose model
        "input_cost": 0.15,
        "output_cost": 0.6,
        "context": 128_000,
    },
    {
        "name": "google/gemini-pro",  # advanced reasoning model
        "input_cost": 0.50,
        "output_cost": 2.50,
        "context": 1_000_000,
    },
    {
        "name": "deepseek/deepseek-coder-v2",  # coding‑optimised model
        "input_cost": 0.27,
        "output_cost": 1.10,
        "context": 128_000,
    },
]


def _choose_model(cfg: Config) -> str:
    """Select an OpenRouter model based on configuration and cost effectiveness.

    If ``cfg.openrouter_model`` is set it is returned directly. Otherwise
    models from the catalogue are filtered by the ``cfg.openrouter_max_cost``
    threshold (combined input + output cost per million tokens). From the
    remaining candidates the model with the lowest cost per token
    (calculated as ``(input_cost + output_cost) / (context / 1_000_000)``)
    is selected. If no model meets the threshold the candidate with the
    lowest cost per token is chosen from the full catalogue.
    """
    # Use user‑configured model if provided
    model_override = cfg.openrouter_model.strip()
    if model_override:
        return model_override
    # Determine threshold
    max_cost = cfg.openrouter_max_cost
    # Filter candidates by cost threshold
    candidates = []
    for m in _MODEL_CATALOGUE:
        total_cost = float(m.get("input_cost", 0.0)) + float(m.get("output_cost", 0.0))
        if total_cost <= max_cost:
            candidates.append(m)
    # If no candidates within threshold, fallback to full list
    if not candidates:
        candidates = list(_MODEL_CATALOGUE)
    # Compute cost per token (higher context lowers the ratio)
    def cost_per_token(m: Dict[str, float | str]) -> float:
        total_cost = float(m.get("input_cost", 0.0)) + float(m.get("output_cost", 0.0))
        context = float(m.get("context", 1.0))
        if context <= 0:
            return float("inf")
        # Cost per million tokens
        return total_cost / (context / 1_000_000)

    best = min(candidates, key=cost_per_token)
    return str(best["name"])


def _cache_file(config: Config) -> Path:
    """Return the path to the suggestions cache file."""
    return config.cache_dir / "suggestion_cache.json"


def read_cache(config: Config) -> Dict[str, str]:
    """Return cached suggestions as a dictionary.

    If no cache is present or the file is corrupted, an empty dictionary is returned.
    """
    path = _cache_file(config)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def clear_cache(config: Config) -> bool:
    """Remove the suggestions cache file.

    Returns ``True`` if a cache file existed and was deleted.
    """
    path = _cache_file(config)
    if path.exists():
        try:
            path.unlink()
            return True
        except OSError:
            return False
    return False


def stream_suggestion(config: Config, question: str, *, model: Optional[str] = None) -> Generator[str, None, Optional[str]]:
    """Stream a suggestion for ``question``.

    This simplified implementation does not perform true streaming from the API due
    to the limitations of the environment. Instead it falls back to a single
    request via :func:`get_suggestion` and yields the entire answer. A final
    return value equal to the answer is provided for API parity.

    If the answer is cached it will be yielded immediately.
    """
    # If cached, yield and return cached answer
    cache = read_cache(config)
    if question in cache:
        yield cache[question]
        return cache[question]
    answer = get_suggestion(config, question)
    if answer:
        yield answer
    return answer


def get_suggestion(config: Config, question: str) -> Optional[str]:
    """Ask OpenRouter for a suggestion about ``question``.

    Returns a string if a suggestion was retrieved, otherwise ``None``.
    """
    # Respect the network toggle: when disabled, fall back to an offline suggestion.
    if not config.network_enabled:
        # Offline mode: attempt to answer using local context. If that fails,
        # return a generic message indicating the network is disabled.
        return _offline_suggestion(config, question)
    # Check if suggestions are enabled and an API key is present
    if not config.suggestions_enabled:
        return None
    api_key = config.openrouter_api_key
    if not api_key:
        return None
    # Attempt to load cached suggestions
    cache = read_cache(config)
    if question in cache:
        return cache[question]
    try:
        url = "https://openrouter.ai/api/v1/chat/completions"
        # Determine the model to use based on the configuration
        model = _choose_model(config)
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "messages": [
                {"role": "user", "content": question}
            ],
            "stream": False,
            # Pass OpenRouter parameters from config for deeper control
            "temperature": config.openrouter_temperature,
            "max_tokens": config.openrouter_max_tokens,
            "top_p": config.openrouter_top_p,
        }
        resp = requests.post(url, headers=headers, json=payload, timeout=30)
        if resp.status_code != 200:
            return None
        data = resp.json()
        choices = data.get("choices") or []
        if not choices:
            return None
        message = choices[0].get("message", {})
        answer = message.get("content")
        if answer:
            # Update cache
            cache[question] = answer
            try:
                _cache_file(config).write_text(json.dumps(cache, indent=2) + "\n", encoding="utf-8")
            except OSError:
                pass
        return answer
    except Exception:
        # On any error, fail silently
        return None

# Offline suggestion helper
def _offline_suggestion(config: Config, question: str) -> Optional[str]:
    """Generate a best‑effort suggestion without using the network.

    This function reads the project's context snapshot (if available) or
    dynamically generates it using :mod:`context_tools`. It then searches
    for the words in ``question`` within the context and returns a short
    excerpt. If no relevant section is found the function returns a
    truncated summary of the context. This provides a minimal offline
    fallback when network access is disabled.

    Parameters
    ----------
    config:
        The configuration instance, used to locate the project root.
    question:
        The user question.

    Returns
    -------
    Optional[str]
        A string containing the suggested answer or ``None`` if no
        context is available.
    """
    # Locate the project root. context_tools uses parents[2], but our config
    # class stores snapshot files in the root directory (parent of zdownloadmanager).
    try:
        from . import context_tools  # import lazily to avoid circular deps
    except Exception:
        return None
    from pathlib import Path
    # Compute root directory
    root = Path(__file__).resolve().parents[2]
    ctx_path = root / "context_snapshot.md"
    if ctx_path.exists():
        try:
            text = ctx_path.read_text(encoding="utf-8")
        except Exception:
            text = ""
    else:
        # Generate context snapshot dynamically
        try:
            md, _ = context_tools.generate_context_snapshot()
            text = md
        except Exception:
            text = ""
    if not text:
        return "Network is disabled and no context is available."
    # Simple search: check for lines containing all non‑trivial words
    words = [w.lower() for w in question.split() if len(w) > 3]
    lines = text.splitlines()
    for idx, line in enumerate(lines):
        if words and all(word in line.lower() for word in words):
            # Return this line and the following two lines as context
            excerpt = "\n".join(lines[idx:idx+3])
            return excerpt.strip()
    # Fallback: return the first 400 characters of context
    return text[:400].strip() + ("..." if len(text) > 400 else "")