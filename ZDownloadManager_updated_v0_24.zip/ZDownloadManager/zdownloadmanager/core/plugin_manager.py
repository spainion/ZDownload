"""Plugin system for ZDownloadManager.

This module introduces a lightweight plugin architecture that allows
developers to extend the functionality of ZDownloadManager without
modifying the core codebase.  Plugins live in a ``plugins`` directory
at the project root and are loaded at runtime via
:func:`load_plugins`.  Each plugin is a Python module that may
define a ``register()`` function to perform any initialisation or
registration with the host application.  Any import errors are
reported but do not prevent other plugins from loading.

Example
-------

Create a file ``plugins/example.py`` in your project with the
following contents::

    def register():
        print("Example plugin registered!")

At startup call ``load_plugins()`` to discover and initialise the
plugin::

    from zdownloadmanager.core.plugin_manager import load_plugins
    load_plugins()

Any number of plugins can be added.  The plugins directory is
automatically created on demand when :func:`load_plugins` is
executed for the first time.

Version: 0.1
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from types import ModuleType
from typing import List

__all__ = ["load_plugins", "plugin_hooks"]


# Registry of plugin hooks.  Keys are hook names (e.g. 'on_start') and
# values are lists of callables.  Plugins can define functions with
# names starting with 'on_' to register for a lifecycle event.  The
# application can then invoke these hooks at the appropriate time.
plugin_hooks: dict[str, list] = {}


def load_plugins(root: Path | None = None) -> List[ModuleType]:
    """Discover and load plugin modules from the ``plugins`` directory.

    Parameters
    ----------
    root: Path or None, optional
        The project root.  If ``None`` (the default), it is resolved to
        two levels above this file.  Plugins are searched under
        ``root / 'plugins'``.

    Returns
    -------
    List[ModuleType]
        A list of successfully loaded plugin modules.  Modules that fail
        to import are skipped with an error message printed to stderr.

    Notes
    -----
    Plugin modules should avoid heavy imports at module top-level.  Any
    expensive work should be performed in a ``register()`` function so
    that it can be controlled by the host application.  If a plugin
    defines ``register()``, it is invoked automatically after the
    module is loaded.  Plugins that do not define this function are
    still loaded and returned to the caller but no further action is
    taken.
    """
    if root is None:
        root = Path(__file__).resolve().parents[2]
    plugins_dir = root / "plugins"
    # Ensure the directory exists so clients can drop plugins into it
    plugins_dir.mkdir(parents=True, exist_ok=True)
    loaded: List[ModuleType] = []
    # Prepend the project root to sys.path if not already present so
    # that ``plugins`` can be imported as a package.  This is safe to do
    # multiple times because sys.path ignores duplicates.
    project_root = str(root)
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    for path in plugins_dir.iterdir():
        # Only consider Python files
        if path.is_file() and path.suffix == ".py" and path.name != "__init__.py":
            module_name = f"plugins.{path.stem}"
            try:
                mod = importlib.import_module(module_name)
            except Exception as e:
                print(f"Failed to import plugin {module_name}: {e}", file=sys.stderr)
                continue
            # If the module defines a register() function, call it
            register = getattr(mod, "register", None)
            if callable(register):
                try:
                    register()
                except Exception as e:
                    print(f"Error registering plugin {module_name}: {e}", file=sys.stderr)
            # Discover hook functions (any callables starting with 'on_')
            for attr_name in dir(mod):
                if attr_name.startswith("on_"):
                    fn = getattr(mod, attr_name)
                    if callable(fn):
                        plugin_hooks.setdefault(attr_name, []).append(fn)
            loaded.append(mod)
    return loaded