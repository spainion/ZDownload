"""Context and code snapshot utilities for ZDownloadManager.

This module provides helper functions to build dependency maps, generate
context and code snapshots and query import relationships between
modules. It mirrors functionality in the upstream ZDownload project
but avoids reliance on a Git repository or external tools. These
utilities can be used by the CLI to introspect the project structure
and to assist agents working on the codebase.
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Dict, List, Tuple, Any

# Resolve the project root relative to this file. The structure is
# zdownloadmanager/core/context_tools.py -> core -> zdownloadmanager -> ZDownloadManager
ROOT = Path(__file__).resolve().parents[2]


def build_dependency_map() -> Dict[str, List[str]]:
    """Return a mapping of Python source files to in‑repo import targets.

    The keys in the returned dictionary are paths relative to the
    project root. The values are lists of relative paths that the key
    imports at the top level. Only imports within the repository are
    considered; standard library or external modules are ignored.
    
    This function scans all ``.py`` files under the project root,
    constructs a module name for each and uses the abstract syntax
    tree to walk import statements. For each import it attempts to
    resolve the module back to a file in the project. If an import
    cannot be resolved it is ignored. The resulting dependency map
    captures the high‑level relationships between modules and can be
    used to answer questions about which files depend on which others.
    """
    py_files = [p for p in ROOT.rglob("*.py") if ".venv" not in p.parts]
    module_map: Dict[str, Path] = {}
    # Build a mapping from dotted module name to file path
    for path in py_files:
        rel = path.relative_to(ROOT)
        module_map[".".join(rel.with_suffix("").parts)] = rel
    dep_map: Dict[str, List[str]] = {}
    for path in py_files:
        rel = path.relative_to(ROOT)
        module_name = ".".join(rel.with_suffix("").parts)
        deps: set[str] = set()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception:
            # Skip files that cannot be parsed
            dep_map[str(rel)] = []
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    mod = alias.name
                    # Walk up the module hierarchy until we find a local file
                    while mod:
                        target = module_map.get(mod)
                        if target:
                            deps.add(str(target))
                            break
                        # Trim one level from the end
                        mod = ".".join(mod.split(".")[:-1])
            elif isinstance(node, ast.ImportFrom):
                base = node.module or ""
                if node.level:
                    # Relative import: adjust based on module depth
                    parts = module_name.split(".")
                    base = ".".join(parts[:-node.level] + ([node.module] if node.module else []))
                mod = base
                while mod:
                    target = module_map.get(mod)
                    if target:
                        deps.add(str(target))
                        break
                    mod = ".".join(mod.split(".")[:-1])
        dep_map[str(rel)] = sorted(deps)
    return dep_map


def generate_context_snapshot() -> Tuple[str, Dict[str, Any]]:
    """Generate a combined Markdown and JSON context snapshot.

    The context snapshot concatenates the contents of all Markdown files
    in the repository (excluding the generated ``context_snapshot.md``)
    and appends a dependency graph section based on the import
    relationships returned by :func:`build_dependency_map`. The JSON
    portion contains a mapping of file paths to their text and the
    dependency map for programmatic inspection.

    Returns
    -------
    tuple
        A tuple of ``(markdown_text, json_data)`` where
        ``markdown_text`` is a Markdown string and ``json_data`` is
        a dictionary with keys ``"files"`` and ``"dependencies"``.
    """
    # Collect all Markdown files except the snapshot itself
    files = sorted(p for p in ROOT.rglob("*.md") if p.name != "context_snapshot.md")
    sections: List[str] = []
    file_map: Dict[str, str] = {}
    for path in files:
        rel = path.relative_to(ROOT)
        # Read file content and normalise line endings
        raw = path.read_text(encoding="utf-8")
        text = "\n".join(line.rstrip() for line in raw.splitlines())
        sections.append(f"# File: {rel}\n\n{text}\n")
        file_map[str(rel)] = text
    deps = build_dependency_map()
    dep_lines = [f"- {f}: {', '.join(d) if d else '[]'}" for f, d in sorted(deps.items())]
    combined = (
        "\n".join(sections)
        + "\n## Dependency graph\n\n"
        + "\n".join(dep_lines)
    )
    # Upstream includes recent commit log and git status in the context snapshot.
    # In this environment we may not have a git repository, so populate log and status
    # with empty values for compatibility. Agents can still rely on the dependency map
    # and file contents for context.
    return combined, {
        "files": file_map,
        "dependencies": deps,
        "log": "",
        "status": "clean\n",
    }


def generate_code_summary() -> Dict[str, Dict[str, Any]]:
    """Return a summary of top‑level functions and classes in Python files.

    The returned mapping has relative file paths as keys and a dictionary
    with two keys: ``"functions"`` listing function signatures and
    ``"classes"`` mapping class names to method signatures. Files in
    any virtual environment directory are ignored.
    """
    summary: Dict[str, Dict[str, Any]] = {}
    for file in sorted(ROOT.rglob("*.py")):
        # Skip typical virtual environment directories
        if any(part in {".venv", "venv", "env"} for part in file.parts):
            continue
        rel = file.relative_to(ROOT)
        try:
            tree = ast.parse(file.read_text(encoding="utf-8"))
        except Exception:
            continue
        functions: List[str] = []
        classes: Dict[str, List[str]] = {}
        for node in tree.body:
            if isinstance(node, ast.FunctionDef):
                functions.append(f"{node.name}({', '.join([arg.arg for arg in node.args.args])})")
            elif isinstance(node, ast.ClassDef):
                methods: List[str] = []
                for item in node.body:
                    if isinstance(item, ast.FunctionDef):
                        methods.append(f"{item.name}({', '.join([arg.arg for arg in item.args.args])})")
                classes[node.name] = methods
        summary[str(rel)] = {"functions": functions, "classes": classes}
    return summary


def build_code_markdown(summary: Dict[str, Dict[str, Any]]) -> str:
    """Construct a Markdown document from a code summary.

    Parameters
    ----------
    summary:
        A mapping from file paths to function/class information as
        returned by :func:`generate_code_summary`.
    
    Returns
    -------
    str
        A Markdown string describing each file with bullet points for
        functions and classes.
    """
    lines: List[str] = ["# Code Snapshot", ""]
    for file, info in summary.items():
        lines.append(f"## {file}")
        for func in info.get("functions", []):
            lines.append(f"- {func}")
        for cls, methods in info.get("classes", {}).items():
            lines.append(f"- class {cls}")
            for method in methods:
                lines.append(f"  - {method}")
        lines.append("")
    if lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"


def get_dependencies(path: str) -> List[str]:
    """Return a list of dependencies for the given file.

    If the file is not found in the dependency map an empty list is returned.
    """
    deps = build_dependency_map()
    return deps.get(path, [])


def get_dependents(path: str) -> List[str]:
    """Return a list of modules that depend on the given file.

    The dependency map is inverted to find all keys where ``path`` appears in
    the dependency list.
    """
    deps = build_dependency_map()
    dependents: List[str] = []
    for mod, dlist in deps.items():
        if path in dlist:
            dependents.append(mod)
    return sorted(dependents)