"""
Memory Graph Manager
====================

This module provides a simple in‑memory graph for storing code entities and
their relationships, inspired by the HelixHyper project.  It defines
``Node`` and ``MemoryGraph`` classes along with a helper to build a graph
from a context snapshot.  The resulting graph can be serialised to JSON for
persistence or further analysis.

Classes
-------
- **Node** – represents a code entity (e.g. file, function) with optional
  metadata and directed edges to other nodes.
- **MemoryGraph** – container for nodes with a version string that
  increments on each modification.

Functions
---------
- **build_graph_from_context(context_path: Path) -> MemoryGraph** – reads
  ``context_snapshot.json`` and constructs a ``MemoryGraph`` representing
  files and import relationships.  Nodes are created for each file and an
  ``imports`` edge is added from each file to its dependencies.

Example usage::

    from zdownloadmanager.core.memory_graph_manager import build_graph_from_context
    graph = build_graph_from_context(Path('context_snapshot.json'))
    graph_json = graph.to_dict()

Version: 0.1
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Set
import json


@dataclass
class Node:
    """Simple node holding content, metadata and outgoing edges."""

    id: str
    content: str
    metadata: dict | None = None
    edges: Dict[str, Set[str]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.metadata is None:
            self.metadata = {}


class MemoryGraph:
    """A directed graph of :class:`Node` objects with version tracking."""

    def __init__(self) -> None:
        self.nodes: Dict[str, Node] = {}
        self.version: str = "0.00"

    def _next_id(self) -> str:
        return str(len(self.nodes))

    def add_node(self, content: str, metadata: dict | None = None) -> Node:
        node_id = self._next_id()
        node = Node(node_id, content, metadata)
        self.nodes[node_id] = node
        return node

    def link_nodes(self, src_id: str, relation: str, dst_id: str) -> None:
        src = self.nodes[src_id]
        src.edges.setdefault(relation, set()).add(dst_id)

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "nodes": {
                nid: {
                    "content": node.content,
                    "metadata": node.metadata,
                    "edges": {rel: list(targets) for rel, targets in node.edges.items()},
                }
                for nid, node in self.nodes.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MemoryGraph":
        g = cls()
        g.version = str(data.get("version", "0.00"))
        for nid, ndata in data.get("nodes", {}).items():
            node = Node(nid, ndata.get("content", ""), ndata.get("metadata"), {})
            edges_dict = {}
            for rel, ids in ndata.get("edges", {}).items():
                edges_dict[rel] = set(ids)
            node.edges = edges_dict
            g.nodes[nid] = node
        return g

    def bump_version(self) -> None:
        try:
            v = float(self.version)
        except Exception:
            v = 0.0
        v += 0.01
        self.version = f"{v:.2f}"


def compute_strongly_connected_components(graph: "MemoryGraph") -> list[list[str]]:
    """Return a list of strongly connected components (SCCs) in the graph.

    Each component is represented as a list of node IDs.  Components of
    size greater than one indicate cycles in the import graph.  The
    algorithm implemented here is Tarjan's algorithm with iterative
    traversal to avoid recursion limits.

    Parameters
    ----------
    graph : MemoryGraph
        The graph to analyse.

    Returns
    -------
    list[list[str]]
        A list of components sorted by discovery order.
    """
    index = 0
    indices: dict[str, int] = {}
    lowlink: dict[str, int] = {}
    stack: list[str] = []
    on_stack: set[str] = set()
    sccs: list[list[str]] = []

    def strongconnect(node_id: str) -> None:
        nonlocal index
        indices[node_id] = index
        lowlink[node_id] = index
        index += 1
        stack.append(node_id)
        on_stack.add(node_id)
        # Consider successors
        for rel, targets in graph.nodes[node_id].edges.items():
            for succ in targets:
                if succ not in indices:
                    strongconnect(succ)
                    lowlink[node_id] = min(lowlink[node_id], lowlink[succ])
                elif succ in on_stack:
                    lowlink[node_id] = min(lowlink[node_id], indices[succ])
        # If node is a root node, pop the stack and generate an SCC
        if lowlink[node_id] == indices[node_id]:
            component: list[str] = []
            while True:
                w = stack.pop()
                on_stack.remove(w)
                component.append(w)
                if w == node_id:
                    break
            sccs.append(component)

    for node_id in graph.nodes:
        if node_id not in indices:
            strongconnect(node_id)
    return sccs


def find_most_dependent_nodes(graph: "MemoryGraph", top_n: int = 5) -> list[tuple[str, int]]:
    """Return the nodes with the highest number of inbound edges.

    The number of inbound edges for a node corresponds to how many other
    files import it.  Identifying nodes with a high import count can
    highlight central modules or potential bottlenecks.

    Parameters
    ----------
    graph : MemoryGraph
        The graph to analyse.
    top_n : int
        The maximum number of nodes to return.

    Returns
    -------
    list[tuple[str, int]]
        A list of (node_id, inbound_count) tuples sorted by inbound
        count descending.
    """
    inbound_counts: dict[str, int] = {nid: 0 for nid in graph.nodes}
    for src_id, node in graph.nodes.items():
        for relation_targets in node.edges.values():
            for tgt in relation_targets:
                inbound_counts[tgt] = inbound_counts.get(tgt, 0) + 1
    # Sort by count descending
    sorted_nodes = sorted(inbound_counts.items(), key=lambda item: item[1], reverse=True)
    return sorted_nodes[:top_n]


def build_graph_from_context(context_path: Path) -> MemoryGraph:
    """Construct a MemoryGraph from a context snapshot.

    Parameters
    ----------
    context_path: Path
        Path to ``context_snapshot.json`` produced by ``context_snapshot.py``.

    Returns
    -------
    MemoryGraph
        A graph where each node represents a file and an ``imports`` edge
        connects a file to the files it depends on.
    """
    data = json.loads(context_path.read_text(encoding="utf-8"))
    deps: Dict[str, list] = data.get("dependencies", {})
    graph = MemoryGraph()
    # Map file names to node ids
    file_to_id: Dict[str, str] = {}
    # Create nodes
    for file_name in deps.keys():
        node = graph.add_node(file_name, {"type": "file"})
        file_to_id[file_name] = node.id
    # Add edges for dependencies
    for file_name, children in deps.items():
        src_id = file_to_id.get(file_name)
        if not src_id:
            continue
        for dep in children:
            dst_id = file_to_id.get(dep)
            if dst_id is None:
                # Create node for unseen dependency
                node = graph.add_node(dep, {"type": "file"})
                dst_id = node.id
                file_to_id[dep] = dst_id
            graph.link_nodes(src_id, "imports", dst_id)
    graph.bump_version()
    return graph