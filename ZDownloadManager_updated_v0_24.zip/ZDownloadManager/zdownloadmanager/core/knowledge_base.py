"""A lightweight persistent knowledge base for storing scraped web pages.

This module provides a simple SQLite‑backed knowledge base that stores web
page content scraped by the built‑in scraper. Each entry in the knowledge
base includes the page URL, title, main text, an optional summary, and
metadata such as headings, image sources, meta tags, and outbound links.
Entries are deduplicated using a content hash, allowing the caller to
determine whether a page has changed since the last scrape. A full‑text
search index is maintained via SQLite's FTS5 extension to enable fast
keyword queries over page titles and text.
"""

from __future__ import annotations

import json
import hashlib
import os
import sqlite3
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

class KnowledgeBase:
    """A simple on‑disk knowledge base for scraped pages."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        # Ensure parent directory exists
        os.makedirs(db_path.parent, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path))
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        cur = self.conn.cursor()
        # Main table holds raw data and metadata as JSON
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS pages (
                url TEXT PRIMARY KEY,
                title TEXT,
                text TEXT,
                summary TEXT,
                headings TEXT,
                images TEXT,
                meta TEXT,
                links TEXT,
                content_hash TEXT,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        # FTS table for searching titles and text
        cur.execute(
            """
            CREATE VIRTUAL TABLE IF NOT EXISTS pages_fts USING fts5(
                url, title, text,
                content='pages', content_rowid='rowid'
            )
            """
        )
        self.conn.commit()

    def _hash_content(self, text: str) -> str:
        return hashlib.sha256(text.encode('utf-8')).hexdigest()

    def store_page(self, url: str, data: Dict[str, Any]) -> None:
        """Insert or update a page record in the knowledge base.

        Parameters
        ----------
        url: str
            The unique URL of the page.
        data: Dict[str, Any]
            A dictionary containing fields from :func:`scrape_page` or
            :func:`scrape_site`. Required keys are ``title`` and ``text``;
            optional keys include ``summary``, ``headings``, ``images``,
            ``meta``, and ``links``.
        """
        title = data.get("title") or url
        text = data.get("text") or ""
        summary = data.get("summary")
        headings = json.dumps(data.get("headings")) if data.get("headings") else None
        images = json.dumps(data.get("images")) if data.get("images") else None
        meta = json.dumps(data.get("meta")) if data.get("meta") else None
        links = json.dumps(data.get("links")) if data.get("links") else None
        content_hash = self._hash_content(text)
        cur = self.conn.cursor()
        # Check if existing record has same hash; if so, don't update
        cur.execute("SELECT content_hash FROM pages WHERE url = ?", (url,))
        row = cur.fetchone()
        if row and row[0] == content_hash:
            return
        cur.execute(
            """
            INSERT INTO pages(url, title, text, summary, headings, images, meta, links, content_hash)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(url) DO UPDATE SET
                title=excluded.title,
                text=excluded.text,
                summary=excluded.summary,
                headings=excluded.headings,
                images=excluded.images,
                meta=excluded.meta,
                links=excluded.links,
                content_hash=excluded.content_hash,
                last_updated=CURRENT_TIMESTAMP
            """,
            (
                url,
                title,
                text,
                summary,
                headings,
                images,
                meta,
                links,
                content_hash,
            ),
        )
        # Update FTS table
        # Delete existing FTS record if present to avoid duplicates
        cur.execute("DELETE FROM pages_fts WHERE rowid IN (SELECT rowid FROM pages WHERE url = ?)", (url,))
        cur.execute(
            """
            INSERT INTO pages_fts(rowid, url, title, text)
            SELECT rowid, url, title, text FROM pages WHERE url = ?
            """,
            (url,),
        )
        self.conn.commit()

    def get_page(self, url: str) -> Optional[Dict[str, Any]]:
        """Retrieve a page from the knowledge base by URL."""
        cur = self.conn.cursor()
        cur.execute(
            "SELECT url, title, text, summary, headings, images, meta, links, last_updated FROM pages WHERE url = ?",
            (url,),
        )
        row = cur.fetchone()
        if not row:
            return None
        url, title, text, summary, headings, images, meta, links, last_updated = row
        return {
            "url": url,
            "title": title,
            "text": text,
            "summary": summary,
            "headings": json.loads(headings) if headings else None,
            "images": json.loads(images) if images else None,
            "meta": json.loads(meta) if meta else None,
            "links": json.loads(links) if links else None,
            "last_updated": last_updated,
        }

    def search(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Perform a full‑text search over stored pages and return summaries.

        Parameters
        ----------
        query: str
            The search query. Uses SQLite FTS5 syntax.
        limit: int, optional
            Maximum number of results to return (default 10).

        Returns
        -------
        List[Dict[str, Any]]
            A list of dictionaries with keys ``url``, ``title``, and
            ``snippet`` (an excerpt from the matching content).
        """
        cur = self.conn.cursor()
        cur.execute(
            """
            SELECT p.url, p.title, snippet(pages_fts, 2, '<b>', '</b>', '…', 64)
            FROM pages_fts
            JOIN pages p ON pages_fts.rowid = p.rowid
            WHERE pages_fts MATCH ?
            ORDER BY rank
            LIMIT ?
            """,
            (query, limit),
        )
        results: List[Dict[str, Any]] = []
        for url, title, snippet in cur.fetchall():
            results.append({"url": url, "title": title, "snippet": snippet})
        return results

    def close(self) -> None:
        self.conn.close()
