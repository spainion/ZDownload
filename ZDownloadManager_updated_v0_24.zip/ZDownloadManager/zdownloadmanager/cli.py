"""Command line interface for ZDownloadManager.

This script provides a basic CLI for downloading files using the segmented
downloader and then organising them into the library. It accepts a primary
URL and an optional comma‑separated list of mirrors. It can be used as a
simple default download handler or invoked by the Chrome bridge.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from typing import Optional, Any, Dict, List

from .core.config import Config
from .core.downloader import SegmentedDownloader, DownloadError
from .core.organizer import Organizer
from .core.library import Library
from .core import suggestions
from .core.suggestions import stream_suggestion
from .core import context_tools
from . import __version__
import requests
from html.parser import HTMLParser
import sys


def main(argv: Optional[list[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="ZDownloadManager command line interface")
    # Download arguments
    parser.add_argument("url", nargs="?", help="Primary download URL")
    parser.add_argument("-o", "--output", dest="output", default=None, help="Destination file path")
    parser.add_argument("--mirrors", dest="mirrors", default="", help="Comma separated list of mirror URLs")
    parser.add_argument("--piece", dest="piece_size", type=int, default=None, help="Piece size in bytes (default from config)")
    parser.add_argument("--conc", dest="concurrency", type=int, default=None, help="Number of concurrent pieces (default from config)")
    # Suggestion and model arguments
    parser.add_argument("--suggest", dest="suggest", help="Ask the AI a question and output the answer")
    parser.add_argument("--suggest-model", dest="suggest_model", help="Specify the OpenRouter model for suggestion")
    parser.add_argument("--suggest-temperature", dest="suggest_temperature", type=float, help="Override temperature for suggestions")
    parser.add_argument("--suggest-max-tokens", dest="suggest_max_tokens", type=int, help="Override max tokens for suggestions")
    parser.add_argument("--suggest-top-p", dest="suggest_top_p", type=float, help="Override top_p for suggestions")
    parser.add_argument("--suggest-stream", dest="suggest_stream", action="store_true", help="Stream the AI answer")
    parser.add_argument("--clear-suggestions-cache", action="store_true", help="Clear the suggestions cache and exit")
    parser.add_argument("--show-suggestions-cache", action="store_true", help="Show cached suggestions and exit")
    # Model list and config introspection
    parser.add_argument("--list-models", dest="list_models", action="store_true", help="List known models and exit")
    parser.add_argument("--show-config", dest="show_config", action="store_true", help="Print the current configuration and exit")
    parser.add_argument("--version", dest="version", action="store_true", help="Print the program version and exit")
    # Library inspection
    parser.add_argument("--list-library", dest="list_library", action="store_true", help="List files in the library and exit")
    parser.add_argument("--search-library", dest="search_library", help="Search library for files or tags and exit")
    parser.add_argument("--library-stats", dest="library_stats", action="store_true", help="Show category and tag statistics and exit")
    # Snapshot and dependency inspection
    parser.add_argument("--show-context-snapshot", dest="show_context_snapshot", action="store_true", help="Print the context snapshot and exit")
    parser.add_argument("--show-code-snapshot", dest="show_code_snapshot", action="store_true", help="Print the code snapshot and exit")
    parser.add_argument("--verify-snapshots", dest="verify_snapshots", action="store_true", help="Verify context and code snapshots are up to date")
    parser.add_argument("--show-dependencies", dest="show_dependencies", help="Show dependencies for the given Python file relative to the project root")
    parser.add_argument("--show-dependents", dest="show_dependents", help="Show modules that depend on the given Python file relative to the project root")
    # Network toggle
    parser.add_argument("--enable-network", dest="enable_network", action="store_true", help="Enable network access for this run and persist the setting")
    parser.add_argument("--disable-network", dest="disable_network", action="store_true", help="Disable network access for this run and persist the setting")
    # Web scraping helper (simple link extraction)
    parser.add_argument("--scrape", dest="scrape", help="Scrape a URL and list the links contained")
    # Advanced web scraping helper using the built‑in scraper
    parser.add_argument("--scrape-url", dest="scrape_url", help="Scrape a URL and output structured data")
    parser.add_argument("--scrape-depth", dest="scrape_depth", type=int, default=0, help="Recursively scrape up to this depth of links")
    parser.add_argument("--scrape-headings", dest="scrape_headings", action="store_true", help="Include headings in scrape output")
    parser.add_argument("--scrape-images", dest="scrape_images", action="store_true", help="Include images in scrape output")
    parser.add_argument("--scrape-meta", dest="scrape_meta", action="store_true", help="Include meta tags in scrape output")
    parser.add_argument("--scrape-links", dest="scrape_links_flag", action="store_true", help="Include links in scrape output")
    parser.add_argument("--scrape-summary", dest="scrape_summary", action="store_true", help="Summarise the page content via AI")
    # Knowledge base operations
    parser.add_argument("--scrape-store", dest="scrape_store", action="store_true", help="Store scraped data in the knowledge base")
    parser.add_argument("--scrape-search", dest="scrape_search", help="Search the knowledge base for a query and exit")
    parser.add_argument("--scrape-get", dest="scrape_get", help="Retrieve a stored page from the knowledge base by URL and exit")
    args = parser.parse_args(argv)

    cfg = Config()
    # Apply network toggle overrides
    if args.enable_network:
        cfg.update(network_enabled=True)
    if args.disable_network:
        cfg.update(network_enabled=False)

    # Handle version and config introspection
    if args.version:
        print(f"ZDownloadManager version {__version__}")
        return
    if args.show_config:
        import json
        print(json.dumps(cfg.data, indent=2))
        return

    # Handle model listing
    if args.list_models:
        print("Available models:")
        for m in suggestions._MODEL_CATALOGUE:
            total_cost = m.get("input_cost", 0.0) + m.get("output_cost", 0.0)
            ctx = m.get("context", 0)
            name = m.get("name")
            print(f"- {name}: cost={total_cost}/M tokens, context={ctx}")
        return

    # Handle suggestions cache operations
    if args.clear_suggestions_cache:
        removed = suggestions.clear_cache(cfg)
        if removed:
            print("Suggestions cache cleared")
        else:
            print("No suggestions cache found")
        return
    if args.show_suggestions_cache:
        cache = suggestions.read_cache(cfg)
        if not cache:
            print("No cached suggestions")
        else:
            for q, a in cache.items():
                print(f"Q: {q}\nA: {a}\n")
        return

    # Handle scraping helper
    if args.scrape:
        url = args.scrape
        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            class LinkParser(HTMLParser):
                def __init__(self):
                    super().__init__()
                    self.links: List[str] = []
                def handle_starttag(self, tag, attrs):
                    if tag.lower() == 'a':
                        href = dict(attrs).get('href')
                        if href:
                            self.links.append(href)
            parser = LinkParser()
            parser.feed(resp.text)
            seen = set()
            for link in parser.links:
                if link not in seen:
                    print(link)
                    seen.add(link)
        except Exception as e:
            print(f"Failed to scrape {url}: {e}")
        return

    # Knowledge base search retrieval
    if args.scrape_search:
        from .core.knowledge_base import KnowledgeBase
        kb_path = Path(cfg.data.get("knowledge_db_path"))
        kb = KnowledgeBase(kb_path)
        results = kb.search(args.scrape_search)
        for entry in results:
            print(f"{entry['url']}\t{entry['title']}\t{entry['snippet']}")
        kb.close()
        return
    if args.scrape_get:
        from .core.knowledge_base import KnowledgeBase
        kb_path = Path(cfg.data.get("knowledge_db_path"))
        kb = KnowledgeBase(kb_path)
        entry = kb.get_page(args.scrape_get)
        kb.close()
        import json
        if entry:
            print(json.dumps(entry, indent=2))
        else:
            print("No entry found for URL")
        return

    # Handle advanced scraping helper
    if args.scrape_url:
        from .core import webscraper
        url = args.scrape_url
        depth = args.scrape_depth
        headings = args.scrape_headings
        images_flag = args.scrape_images
        meta_flag = args.scrape_meta
        links_flag = args.scrape_links_flag
        summary = args.scrape_summary
        if depth > 0:
            data = webscraper.scrape_site(
                url,
                depth=depth,
                headings=headings,
                images=images_flag,
                meta=meta_flag,
                summary=summary,
                links=links_flag,
            )
        else:
            data = webscraper.scrape_page(
                url,
                headings=headings,
                images=images_flag,
                meta=meta_flag,
                summary=summary,
                links=links_flag,
            )
        import json
        # Optionally persist scraped data to the knowledge base
        if args.scrape_store:
            from .core.knowledge_base import KnowledgeBase
            kb_path = Path(cfg.data.get("knowledge_db_path"))
            kb = KnowledgeBase(kb_path)
            if isinstance(data, dict):
                # Single page scrape
                kb.store_page(url, data)
            else:
                # Multi‑page scrape (dict keyed by URL)
                for u, d in data.items():
                    kb.store_page(u, d)
            kb.close()
        print(json.dumps(data, indent=2))
        return

    # Handle library operations
    if args.list_library:
        lib = Library(cfg)
        for path, category, tags in lib.scan():
            print(f"{path}\t{category}\t{', '.join(tags)}")
        return
    if args.search_library:
        lib = Library(cfg)
        for path, category, tags in lib.search(args.search_library):
            print(f"{path}\t{category}\t{', '.join(tags)}")
        return
    if args.library_stats:
        lib = Library(cfg)
        category_counts: Dict[str, int] = {}
        tag_counts: Dict[str, int] = {}
        for _, category, tags in lib.scan():
            category_counts[category] = category_counts.get(category, 0) + 1
            for tag in tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
        print("Category counts:")
        for cat, count in sorted(category_counts.items(), key=lambda x: (-x[1], x[0])):
            print(f"- {cat}: {count}")
        print("Tag counts:")
        for tag, count in sorted(tag_counts.items(), key=lambda x: (-x[1], x[0])):
            print(f"- {tag}: {count}")
        return

    # Handle context snapshot and dependency inspection
    if args.show_context_snapshot:
        # Prefer static snapshot if present, else generate on the fly.
        # Compute project root by going up one parent from the package directory.
        # __file__ points to zdownloadmanager/cli.py; its parent is zdownloadmanager,
        # and its grandparent is the project root directory (ZDownloadManager).
        root = Path(__file__).resolve().parents[1]
        ctx_path = root / "context_snapshot.md"
        if ctx_path.exists():
            print(ctx_path.read_text(encoding="utf-8"))
        else:
            md, _ = context_tools.generate_context_snapshot()
            print(md)
        return
    if args.show_code_snapshot:
        root = Path(__file__).resolve().parents[1]
        code_path = root / "code_snapshot.md"
        if code_path.exists():
            print(code_path.read_text(encoding="utf-8"))
        else:
            summary = context_tools.generate_code_summary()
            md = context_tools.build_code_markdown(summary)
            print(md)
        return
    if args.verify_snapshots:
        # Verify snapshot files exist and are current. If missing or outdated,
        # regenerate them using the snapshot scripts.
        root = Path(__file__).resolve().parents[1]
        ctx_path = root / "context_snapshot.md"
        code_path = root / "code_snapshot.md"
        scripts_dir = root / "scripts"
        # Helper to run a script with optional check
        def run_script(script: str, check: bool = False) -> bool:
            try:
                # Use subprocess to call script in project root
                import subprocess  # imported lazily
                cmd = [sys.executable, str(scripts_dir / script)]
                if check:
                    cmd.append("--check")
                subprocess.check_call(cmd, cwd=root)
                return True
            except Exception:
                return False
        # Attempt to verify snapshots
        ok_ctx = run_script("context_snapshot.py", check=True)
        ok_code = run_script("code_scan.py", check=True)
        if ok_ctx and ok_code:
            print("Snapshots up to date")
        else:
            # Generate snapshots and then verify again
            run_script("context_snapshot.py", check=False)
            run_script("code_scan.py", check=False)
            ok_ctx2 = run_script("context_snapshot.py", check=True)
            ok_code2 = run_script("code_scan.py", check=True)
            if ok_ctx2 and ok_code2:
                print("Snapshots updated and now up to date")
            else:
                print("Failed to update snapshots")
        return
    if args.show_dependencies:
        # If a static context snapshot is available use it, else compute dynamic
        root = Path(__file__).resolve().parents[2]
        json_path = root / "context_snapshot.json"
        deps: Dict[str, List[str]]
        if json_path.exists():
            try:
                import json
                deps = json.loads(json_path.read_text(encoding="utf-8")).get("dependencies", {})
            except Exception:
                deps = context_tools.build_dependency_map()
        else:
            deps = context_tools.build_dependency_map()
        # Normalise the key relative to the project root. The dependency map
        # stores paths without the top‑level package directory (e.g. "zdownloadmanager/cli.py").
        rel_path = Path(args.show_dependencies).as_posix()
        # If the provided path includes the top‑level directory name (like "ZDownloadManager/"),
        # strip it off to match keys in the dependency map.
        # Compute project root relative to this file to derive the project name
        project_root = Path(__file__).resolve().parents[1]
        project_name = project_root.name
        if rel_path.startswith(f"{project_name}/"):
            rel_path = rel_path[len(project_name) + 1:]
        dep_list = deps.get(rel_path, [])
        project_root = Path(__file__).resolve().parents[1]
        project_name = project_root.name
        if not dep_list:
            print("No dependencies found.")
        else:
            # Prefix each dependency with the top‑level project directory to mirror tests
            for dep in dep_list:
                print(f"{project_name}/{dep}")
        return
    if args.show_dependents:
        root = Path(__file__).resolve().parents[2]
        json_path = root / "context_snapshot.json"
        deps: Dict[str, List[str]]
        if json_path.exists():
            try:
                import json
                deps = json.loads(json_path.read_text(encoding="utf-8")).get("dependencies", {})
            except Exception:
                deps = context_tools.build_dependency_map()
        else:
            deps = context_tools.build_dependency_map()
        # Normalise the key relative to the project root as above
        rel_path = Path(args.show_dependents).as_posix()
        # Compute project root relative to this file to derive the project name
        project_root = Path(__file__).resolve().parents[1]
        project_name = project_root.name
        if rel_path.startswith(f"{project_name}/"):
            rel_path = rel_path[len(project_name) + 1:]
        dependents = [mod for mod, dlist in deps.items() if rel_path in dlist]
        project_root = Path(__file__).resolve().parents[1]
        project_name = project_root.name
        if not dependents:
            print("No dependents found.")
        else:
            # Prefix each dependent with the top‑level project directory
            for mod in sorted(dependents):
                print(f"{project_name}/{mod}")
        return

    # Handle suggestions if provided
    if args.suggest:
        question = args.suggest
        # Use overrides if provided
        original_model = cfg.openrouter_model
        original_temp = cfg.openrouter_temperature
        original_max_tokens = cfg.openrouter_max_tokens
        original_top_p = cfg.openrouter_top_p
        updates: Dict[str, Any] = {}
        if args.suggest_model:
            updates["openrouter_model"] = args.suggest_model
        if args.suggest_temperature is not None:
            updates["openrouter_temperature"] = args.suggest_temperature
        if args.suggest_max_tokens is not None:
            updates["openrouter_max_tokens"] = args.suggest_max_tokens
        if args.suggest_top_p is not None:
            updates["openrouter_top_p"] = args.suggest_top_p
        if updates:
            cfg.update(**updates)
        if args.suggest_stream:
            for chunk in stream_suggestion(cfg, question):
                print(chunk, end="", flush=True)
            print()
        else:
            answer = suggestions.get_suggestion(cfg, question)
            if answer:
                print(answer)
            else:
                print("No suggestion available.")
        # Restore config if changed temporarily
        cfg.update(
            openrouter_model=original_model,
            openrouter_temperature=original_temp,
            openrouter_max_tokens=original_max_tokens,
            openrouter_top_p=original_top_p,
        )
        return

    # If no url is provided after handling other options, print help
    if not args.url:
        parser.print_help()
        return

    # Otherwise perform a download
    urls = [args.url] + [u for u in args.mirrors.split(",") if u.strip()]
    dest = Path(args.output) if args.output else Path(Path(args.url).name)
    piece_size = args.piece_size or cfg.piece_size
    concurrency = args.concurrency or cfg.concurrency
    try:
        dl = SegmentedDownloader(urls, dest, piece_size=piece_size, concurrency=concurrency)
        dl.download()
    except DownloadError as e:
        print(f"Download failed: {e}")
        return
    # Before organising the downloaded file into the library, verify that the file has been
    # completely downloaded. This helps avoid moving partial downloads into the library
    expected_size: Optional[int] = None
    try:
        expected_size_str = dl._get_meta("file_size") if hasattr(dl, '_get_meta') else None
        if expected_size_str and expected_size_str.isdigit():
            expected_size = int(expected_size_str)
    except Exception:
        expected_size = None
    try:
        actual_size = dest.stat().st_size
    except Exception:
        actual_size = None
    if expected_size is not None and actual_size is not None and actual_size < expected_size:
        print(
            f"Download incomplete: expected {expected_size} bytes, got {actual_size} bytes. "
            f"File remains at {dest}."
        )
        return
    # Organise into library
    organizer = Organizer(cfg)
    try:
        new_path = organizer.organise(dest)
        print(f"Downloaded and stored at: {new_path}")
    except Exception as e:
        print(f"Failed to organise file: {e}")
        print(f"File remains at: {dest}")


if __name__ == "__main__":
    main()