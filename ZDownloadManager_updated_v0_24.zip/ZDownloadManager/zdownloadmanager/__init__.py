"""Top level package for ZDownloadManager.

This package contains the core downloading and organizing logic, the GUI
components, integration layers for Chrome, and command line interfaces.
"""

__all__ = [
    "core",
    "ui",
    "integration",
]

# Package version. This should be incremented whenever new features are
# added or breaking changes are introduced. It mirrors the upstream
# project's versioning scheme but does not strictly follow semantic
# versioning.
# Increment the version after integrating additional features and bug fixes.
__version__ = "0.1.31"