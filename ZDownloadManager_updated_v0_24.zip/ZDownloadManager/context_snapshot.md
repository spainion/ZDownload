# File: README.md

ZDownloadManager
=================

ZDownloadManager is a cross‑platform download manager and smart file organizer designed to run on
Windows and macOS. It features:

* **Resumable downloads:** Download files from one or more mirrors. If the connection is
  interrupted the manager will use HTTP Range requests to resume from exactly where
  it left off. When Range support is unavailable, it falls back to a sequential
  streaming mode. This technique is part of the HTTP specification and allows
  partial content retrieval【939634575679302†L24-L29】.
* **Byte‑level verification:** Each download is split into pieces and hashed
  using SHA‑256. When resuming, pieces are validated on disk and requeued if
  corrupt.
* **Multi‑source support:** Supply a list of mirror URLs separated by commas. If one
  server fails to deliver a piece the next mirror is tried automatically.
* **Library manager:** Once a download completes it is automatically
  organised into logical categories (programs, packages, other files) and indexed in
  a library. Categories and tags can be defined and adjusted by the user.
* **Smart renaming:** Filenames are normalised by replacing underscores and
  hyphens with spaces【224425605480187†L54-L82】 and heuristically inserting a `v`
  prefix before version numbers. This produces consistently readable names (for
  example `my-file-1.0.zip` becomes `my file v1.0.zip`).
* **Right‑click actions:** The library view exposes a configurable context menu.
  Actions are defined in a JSON file and can launch external programs, run
  scripts or display computed information. A built‑in editor allows editing
  the actions from within the application.
* **Chrome integration:** A native messaging host and a small MV3 extension allow
  Chrome/Chromium to hand off downloads to ZDownloadManager. To install the
  native host, run the appropriate script in `install/` and load the
  extension from `chrome_extension/`.

* **AI suggestions:** When enabled and configured with an OpenRouter API key,
  the manager can query an LLM for contextual information about downloaded
  files. Suggestions are cached on disk to minimise API usage. You can
  control the model, temperature, max tokens and top_p either via the
  configuration dialog or CLI flags.

* **Offline mode & network toggle:** A new `network_enabled` setting in the
  configuration allows you to disable all outbound network requests. When
  disabled, the suggestions engine will provide best‑effort answers using
  the project’s local context snapshot instead of contacting OpenRouter. You
  can persistently enable or disable network access via the Config dialog or
  temporarily override it on the CLI using `--enable-network` or
  `--disable-network`.

* **Introspection & tooling:** The CLI exposes `--version` and
  `--show-config` options to inspect the current version and active
  configuration. Use `--list-models` to list known OpenRouter models and
  their approximate costs and context windows. A built‑in web scraping
  helper prints all links on a page.

* **Snapshot & dependency analysis:** The `scripts/` directory contains
  helpers to generate a context snapshot (`scripts/context_snapshot.py`) and
  a code snapshot (`scripts/code_scan.py`). The CLI includes `--show-context-snapshot`,
  `--show-code-snapshot`, and `--verify-snapshots` flags to view and
  validate these snapshots. You can also query module relationships using
  `--show-dependencies` and `--show-dependents`.

* **GitHub automation:** Utilities in `scripts/github_tools.py` leverage
  PyGithub to commit files, open pull requests, list issues, list pull
  requests and display repository languages. Set the `GITHUB_TOKEN`
  environment variable to a personal access token with repository scope
  before invoking these commands.

Getting Started
---------------

Install the dependencies (at minimum `requests` and `tqdm` for the CLI or
`PyQt5` for the graphical interface) and run the main module:

```bash
pip install -r requirements.txt

# Start the graphical application
python -m zdownloadmanager.ui.main_window

# Or use the CLI
zdm https://example.com/file.iso -o /path/to/file.iso --mirrors https://mirror1.com/file.iso,https://mirror2.com/file.iso
```

The first time you run the GUI, a configuration directory is created in a
platform‑appropriate location. You can customise library roots, piece size,
concurrency, categories and actions via the **Config** dialog.

Packaging & Distribution
------------------------

To produce a stand‑alone build for Windows or macOS you can use
PyInstaller. The project intentionally avoids external native dependencies to
ease packaging. Building the installer is left to distribution tools like
Inno Setup (Windows) or a macOS `pkg`. The `chrome_extension/` directory
contains an example MV3 extension and the `install/` folder has scripts to
install the native messaging host. See their individual readme comments for
details.

License
-------

This software is distributed as free software. Feel free to modify and
redistribute it under the terms of the MIT license.

## New Helper Module (zamida_helpers_v0_01.py)

Recent engineering work has produced a consolidated helper module that builds
on the existing tooling in ZDownloadManager.  The module is versioned
(`zamida_helpers_v0_01.py`) and lives at the root of the project alongside
the other scripts.  It introduces several capabilities that extend the
original feature set without duplicating existing code:

- **Model and suggestions API:** Functions `list_openrouter_models` and
  `get_openrouter_completion` wrap the OpenRouter HTTP API.  They can be
  used to enumerate available models and to obtain completions from
  providers such as Mistral, Grok, DeepSeek or OpenAI.  Set
  `OPENROUTER_API_KEY` in your environment to enable these calls.
- **Context and code snapshot helpers:** Functions
  `generate_context_snapshot`, `generate_code_summary` and
  `build_code_markdown` mirror the behaviour of `scripts/context_snapshot.py`
  and `scripts/code_scan.py`, producing combined Markdown/JSON snapshots of
  documentation and a summary of top‑level functions and classes.  These
  helpers are framework‑agnostic and do not require a Git checkout.
- **GitHub integration through the API gateway:** Functions
  `get_github_repo_info` and `fetch_github_file` retrieve repository
  metadata and file contents via the GitHub connector exposed by the
  `api_tool` server.  They automatically fall back to the GitHub REST API
  when the gateway is unavailable.  Provide a `GITHUB_TOKEN` for
  authenticated API requests.
- **Unified key retrieval:** A `get_api_key` helper replicates the
  `hyperhelix.utils.get_api_key` function from the HelixHyper project.
  It reads environment variables and logs a warning when keys are
  missing, promoting consistent configuration across modules.

To use the module in your own scripts:

```python
from zamida_helpers_v0_01 import (
    list_openrouter_models,
    get_openrouter_completion,
    generate_context_snapshot,
    generate_code_summary,
    build_code_markdown,
    get_github_repo_info,
    fetch_github_file,
    get_api_key,
)

# Ensure keys are set
os.environ['OPENROUTER_API_KEY'] = '<your-key>'
os.environ['GITHUB_TOKEN'] = '<github-token>'

models = list_openrouter_models()
print(models[:5])

reply = get_openrouter_completion(
    "Summarise the purpose of this project", model="openai/gpt-4o", temperature=0.7
)
print(reply)

# Build a context snapshot of this repository
md, snapshot = generate_context_snapshot(Path('.'))
(Path('context_snapshot.md').write_text(md), Path('context_snapshot.json').write_text(json.dumps(snapshot, indent=2)))

# Fetch the README from another repository via the API gateway
other_readme = fetch_github_file('spainion/HelixHyper', 'README.md')
print(other_readme.split('\n')[0])
```

This module centralises common tasks and ensures they work in
restricted environments (e.g. offline or without Git), while still
supporting live API calls when keys are provided.  Future additions
should bump the version number in both the filename and docstring to
preserve traceability.

### Bullet‑proof backup support

To ensure that your work is never lost, a new backup routine is included in
``backup_manager.py``.  This helper script creates timestamped, versioned
archives of your entire ZDownloadManager project.  Run it from the root of
your project as follows:

```
python backup_manager.py --project-dir . --output-dir backups
```

The script will produce a ZIP file named ``ZDownloadManager_<version>_<timestamp>.zip``
in the ``backups/`` directory, excluding the backup directory itself to
prevent nested archives.  See the docstring in ``backup_manager.py`` for
additional details and future enhancement suggestions.

# File: code_snapshot.md

# Code Snapshot

## scripts/code_scan.py
- format_args(args)
- scan_file(path)
- generate_summary(root)
- build_markdown(summary)
- main()

## scripts/github_tools.py
- main()

## scripts/openrouter_models.py
- main()

## scripts/llm_suggest.py
- main()

## scripts/context_snapshot.py
- build_dependency_map()
- generate_snapshot()
- main()

## zdownloadmanager/cli.py
- main(argv)

## zdownloadmanager/__init__.py

## zdownloadmanager/integration/native_messaging_host.py
- read_message()
- write_message(msg)
- main()

## zdownloadmanager/integration/protocol_handler.py
- main(argv)

## zdownloadmanager/ui/actions_editor.py
- class ActionsEditor
  - __init__(self, config, parent)
  - save(self)

## zdownloadmanager/ui/main_window.py
- main()
- class DownloadWorker
  - __init__(self, urls, dest, cfg)
  - run(self)
- class MainWindow
  - __init__(self)
  - _setup_ui(self)
  - _setup_download_tab(self)
  - _setup_library_tab(self)
  - reload_config(self)
  - edit_actions(self)
  - edit_suggestion_settings(self)
  - browse_dest(self)
  - add_download(self)
  - on_download_progress(self, item, done, total)
  - on_download_finished(self, item, new_path, error)
  - refresh_library(self)
  - on_tree_context_menu(self, pos)
  - on_tree_selection_changed(self)
  - open_file(self, path)
  - reveal_file(self, path)
  - add_tag_dialog(self, path)
  - run_action(self, path, cmd_template)
  - run_custom_opener(self, path, opener)
  - rename_file(self, path)
  - delete_file(self, path)
  - choose_library_root(self)

## zdownloadmanager/core/knowledge_base.py
- class KnowledgeBase
  - __init__(self, db_path)
  - _ensure_schema(self)
  - _hash_content(self, text)
  - store_page(self, url, data)
  - get_page(self, url)
  - search(self, query, limit)
  - close(self)

## zdownloadmanager/core/config.py
- _platform_config_dir()
- class Config
  - __init__(self, path)
  - load(self)
  - save(self)
  - piece_size(self)
  - concurrency(self)
  - library_roots(self)
  - categories(self)
  - actions(self)
  - custom_openers(self)
  - suggestions_enabled(self)
  - openrouter_api_key(self)
  - openrouter_model(self)
  - openrouter_max_cost(self)
  - openrouter_temperature(self)
  - openrouter_max_tokens(self)
  - openrouter_top_p(self)
  - network_enabled(self)
  - cache_dir(self)
  - last_version(self)
  - update(self, **kwargs)

## zdownloadmanager/core/organizer.py
- class Organizer
  - __init__(self, config)
  - normalize_filename(self, filename)
  - determine_category(self, filename)
  - organise(self, path)

## zdownloadmanager/core/github_adapter.py
- class GitHubAdapter
  - __init__(self, token)
  - get_repo_info(self, full_name)
  - commit_file(self, repo_full_name, path, content, message, branch)
  - create_pull_request(self, repo_full_name, title, body, head, base)
  - list_open_issues(self, repo_full_name, limit)
  - list_open_pull_requests(self, repo_full_name, limit)
  - list_languages(self, repo_full_name)

## zdownloadmanager/core/context_tools.py
- build_dependency_map()
- generate_context_snapshot()
- generate_code_summary()
- build_code_markdown(summary)
- get_dependencies(path)
- get_dependents(path)

## zdownloadmanager/core/suggestions.py
- _choose_model(cfg)
- _cache_file(config)
- read_cache(config)
- clear_cache(config)
- stream_suggestion(config, question, model)
- get_suggestion(config, question)
- _offline_suggestion(config, question)

## zdownloadmanager/core/library.py
- class Library
  - __init__(self, config)
  - _load_tags(self)
  - _save_tags(self)
  - scan(self)
  - search(self, query)
  - set_tags(self, path, tags)
  - add_tag(self, path, tag)
  - remove_tag(self, path, tag)

## zdownloadmanager/core/downloader.py
- class Piece
- class DownloadError
- class SegmentedDownloader
  - __init__(self, urls, dest, piece_size, concurrency, timeout, user_agent)
  - _init_db(self)
  - _get_meta(self, key)
  - _set_meta(self, key, value)
  - _enumerate_pieces(self, file_size)
  - _load_pieces(self)
  - _save_piece(self, piece)
  - _probe_server(self, url)
  - download(self)
  - _sequential_download(self, file_size)

## zdownloadmanager/core/webscraper.py
- scrape_page(url, headings, images, meta, summary, links, timeout)
- scrape_links(url, timeout)
- scrape_site(url, depth, headings, images, meta, summary, links, timeout)
- class _SimpleHTMLParser
  - __init__(self)
  - handle_starttag(self, tag, attrs)
  - handle_endtag(self, tag)
  - handle_data(self, data)

# File: install/macos_quick_action.md

## macOS Quick Action for ZDownloadManager

To add a Finder Quick Action that sends files to ZDownloadManager:

1. Open **Automator** and create a new **Quick Action**.
2. Set **Workflow receives current** to *files or folders* in *Finder*.
3. From the **Actions** library search for **Run Shell Script** and drag it to the workflow.
4. Set **Shell** to `/bin/bash` and **Pass input** to `as arguments`.
5. Replace the script body with:

   ```bash
   for f in "$@"; do
       python3 -m zdownloadmanager.cli "$f"
   done
   ```

6. Save the Quick Action with a name like **Send to ZDownloadManager**.

After saving, right‑click any file in Finder and choose **Quick Actions → Send to ZDownloadManager** to organise it via the command line.

## Dependency graph

- backup_manager.py: []
- scripts/code_scan.py: []
- scripts/context_snapshot.py: []
- scripts/github_tools.py: zdownloadmanager/core/github_adapter.py
- scripts/llm_suggest.py: []
- scripts/openrouter_models.py: []
- zamida_helpers_v0_01.py: []
- zdownloadmanager/__init__.py: []
- zdownloadmanager/cli.py: zdownloadmanager/core/config.py, zdownloadmanager/core/downloader.py, zdownloadmanager/core/knowledge_base.py, zdownloadmanager/core/library.py, zdownloadmanager/core/organizer.py, zdownloadmanager/core/suggestions.py
- zdownloadmanager/core/config.py: []
- zdownloadmanager/core/context_tools.py: []
- zdownloadmanager/core/downloader.py: []
- zdownloadmanager/core/github_adapter.py: []
- zdownloadmanager/core/knowledge_base.py: []
- zdownloadmanager/core/library.py: zdownloadmanager/core/config.py, zdownloadmanager/core/organizer.py
- zdownloadmanager/core/organizer.py: zdownloadmanager/core/config.py
- zdownloadmanager/core/suggestions.py: zdownloadmanager/core/config.py
- zdownloadmanager/core/webscraper.py: zdownloadmanager/core/config.py
- zdownloadmanager/integration/native_messaging_host.py: zdownloadmanager/cli.py
- zdownloadmanager/integration/protocol_handler.py: zdownloadmanager/cli.py
- zdownloadmanager/ui/actions_editor.py: zdownloadmanager/core/config.py
- zdownloadmanager/ui/main_window.py: zdownloadmanager/core/config.py, zdownloadmanager/core/downloader.py, zdownloadmanager/core/library.py, zdownloadmanager/core/organizer.py, zdownloadmanager/core/suggestions.py, zdownloadmanager/ui/actions_editor.py
