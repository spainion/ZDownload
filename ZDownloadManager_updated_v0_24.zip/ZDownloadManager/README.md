ZDownloadManager
=================

ZDownloadManager is a cross‑platform download manager and smart file organizer designed to run on
Windows and macOS. It features:

* **Resumable downloads:** Download files from one or more mirrors. If the connection is
  interrupted the manager will use HTTP Range requests to resume from exactly where
  it left off. When Range support is unavailable, it falls back to a sequential
  streaming mode. This technique is part of the HTTP specification and allows
  partial content retrieval【939634575679302†L24-L29】.
* **Byte‑level verification:** Each download is split into pieces and hashed
  using SHA‑256. When resuming, pieces are validated on disk and requeued if
  corrupt.
* **Multi‑source support:** Supply a list of mirror URLs separated by commas. If one
  server fails to deliver a piece the next mirror is tried automatically.
* **Library manager:** Once a download completes it is automatically
  organised into logical categories (programs, packages, other files) and indexed in
  a library. Categories and tags can be defined and adjusted by the user.
* **Smart renaming:** Filenames are normalised by replacing underscores and
  hyphens with spaces【224425605480187†L54-L82】 and heuristically inserting a `v`
  prefix before version numbers. This produces consistently readable names (for
  example `my-file-1.0.zip` becomes `my file v1.0.zip`).
* **Right‑click actions:** The library view exposes a configurable context menu.
  Actions are defined in a JSON file and can launch external programs, run
  scripts or display computed information. A built‑in editor allows editing
  the actions from within the application.
* **Chrome integration:** A native messaging host and a small MV3 extension allow
  Chrome/Chromium to hand off downloads to ZDownloadManager. To install the
  native host, run the appropriate script in `install/` and load the
  extension from `chrome_extension/`.

* **AI suggestions:** When enabled and configured with an OpenRouter API key,
  the manager can query an LLM for contextual information about downloaded
  files. Suggestions are cached on disk to minimise API usage. You can
  control the model, temperature, max tokens and top_p either via the
  configuration dialog or CLI flags.

* **Offline mode & network toggle:** A new `network_enabled` setting in the
  configuration allows you to disable all outbound network requests. When
  disabled, the suggestions engine will provide best‑effort answers using
  the project’s local context snapshot instead of contacting OpenRouter. You
  can persistently enable or disable network access via the Config dialog or
  temporarily override it on the CLI using `--enable-network` or
  `--disable-network`.

* **Enhanced web scraping:** The built‑in scraper now uses a connection
  pool with automatic retries and a custom User‑Agent to improve
  reliability.  You can enable link extraction, headings, image and meta
  extraction, or request a natural‑language summary of any page.  The
  scraper respects the `network_enabled` configuration and will operate
  offline when disabled.  For deep crawls you can opt‑in to parallel
  scraping via the `parallel=True` flag on `scrape_site`, which uses
  multithreading to fetch multiple pages concurrently.

* **Introspection & tooling:** The CLI exposes `--version` and
  `--show-config` options to inspect the current version and active
  configuration. Use `--list-models` to list known OpenRouter models and
  their approximate costs and context windows. A built‑in web scraping
  helper prints all links on a page.

* **Snapshot & dependency analysis:** The `scripts/` directory contains
  helpers to generate a context snapshot (`scripts/context_snapshot.py`) and
  a code snapshot (`scripts/code_scan.py`). The CLI includes `--show-context-snapshot`,
  `--show-code-snapshot`, and `--verify-snapshots` flags to view and
  validate these snapshots. You can also query module relationships using
  `--show-dependencies` and `--show-dependents`.

* **Self‑engineering suggestions:** The script `scripts/self_engineer.py`
  queries the AI suggestion system for improvements to the project. For
  example:

  ```bash
  python scripts/self_engineer.py --question "How can we improve the downloader for large files?" --output improvements.md
  ```

  The suggestion is saved to the specified file. If the network is
  disabled or no API key is configured, it falls back to analysing the
  local context snapshot for guidance.

* **GitHub automation:** Utilities in `scripts/github_tools.py` leverage
  PyGithub to commit files, open pull requests, list issues, list pull
  requests and display repository languages. Set the `GITHUB_TOKEN`
  environment variable to a personal access token with repository scope
  before invoking these commands.

Getting Started
---------------

Install the dependencies (at minimum `requests` and `tqdm` for the CLI or
`PyQt5` for the graphical interface) and run the main module:

```bash
pip install -r requirements.txt

# Start the graphical application
python -m zdownloadmanager.ui.main_window

# Or use the CLI
zdm https://example.com/file.iso -o /path/to/file.iso --mirrors https://mirror1.com/file.iso,https://mirror2.com/file.iso
```

The first time you run the GUI, a configuration directory is created in a
platform‑appropriate location. You can customise library roots, piece size,
concurrency, categories and actions via the **Config** dialog.

Packaging & Distribution
------------------------

To produce a stand‑alone build for Windows or macOS you can use
PyInstaller. The project intentionally avoids external native dependencies to
ease packaging. Building the installer is left to distribution tools like
Inno Setup (Windows) or a macOS `pkg`. The `chrome_extension/` directory
contains an example MV3 extension and the `install/` folder has scripts to
install the native messaging host. See their individual readme comments for
details.

### API keys and environment setup

If you plan to use the built‑in AI suggestions, web scraping summaries or
GitHub automation, you must provide API keys.  The following environment
variables are recognised:

- ``OPENROUTER_API_KEY`` – your OpenRouter token for LLM completions.
- ``OPENAI_API_KEY`` – optional OpenAI token for any components that call
  OpenAI directly.
- ``GITHUB_TOKEN`` – a personal access token with repository permissions for
  automation via ``scripts/github_tools.py``.

For convenience during development you can place these secrets in a
``keys.txt`` file in the project root.  The ``init.sh`` script will detect
this file and export the variables automatically.  Do **not** commit
``keys.txt`` to version control or share it publicly.

License
-------

This software is distributed as free software. Feel free to modify and
redistribute it under the terms of the MIT license.

## New Helper Module (zamida_helpers_v0_01.py)

Recent engineering work has produced a consolidated helper module that builds
on the existing tooling in ZDownloadManager.  The module is versioned
(`zamida_helpers_v0_01.py`) and lives at the root of the project alongside
the other scripts.  It introduces several capabilities that extend the
original feature set without duplicating existing code:

- **Model and suggestions API:** Functions `list_openrouter_models` and
  `get_openrouter_completion` wrap the OpenRouter HTTP API.  They can be
  used to enumerate available models and to obtain completions from
  providers such as Mistral, Grok, DeepSeek or OpenAI.  Set
  `OPENROUTER_API_KEY` in your environment to enable these calls.
- **Context and code snapshot helpers:** Functions
  `generate_context_snapshot`, `generate_code_summary` and
  `build_code_markdown` mirror the behaviour of `scripts/context_snapshot.py`
  and `scripts/code_scan.py`, producing combined Markdown/JSON snapshots of
  documentation and a summary of top‑level functions and classes.  These
  helpers are framework‑agnostic and do not require a Git checkout.
- **GitHub integration through the API gateway:** Functions
  `get_github_repo_info` and `fetch_github_file` retrieve repository
  metadata and file contents via the GitHub connector exposed by the
  `api_tool` server.  They automatically fall back to the GitHub REST API
  when the gateway is unavailable.  Provide a `GITHUB_TOKEN` for
  authenticated API requests.
- **Unified key retrieval:** A `get_api_key` helper replicates the
  `hyperhelix.utils.get_api_key` function from the HelixHyper project.
  It reads environment variables and logs a warning when keys are
  missing, promoting consistent configuration across modules.

To use the module in your own scripts:

```python
from zamida_helpers_v0_01 import (
    list_openrouter_models,
    get_openrouter_completion,
    generate_context_snapshot,
    generate_code_summary,
    build_code_markdown,
    get_github_repo_info,
    fetch_github_file,
    get_api_key,
)

# Ensure keys are set
os.environ['OPENROUTER_API_KEY'] = '<your-key>'
os.environ['GITHUB_TOKEN'] = '<github-token>'

models = list_openrouter_models()
print(models[:5])

reply = get_openrouter_completion(
    "Summarise the purpose of this project", model="openai/gpt-4o", temperature=0.7
)
print(reply)

# Build a context snapshot of this repository
md, snapshot = generate_context_snapshot(Path('.'))
(Path('context_snapshot.md').write_text(md), Path('context_snapshot.json').write_text(json.dumps(snapshot, indent=2)))

# Fetch the README from another repository via the API gateway
other_readme = fetch_github_file('spainion/HelixHyper', 'README.md')
print(other_readme.split('\n')[0])
```

This module centralises common tasks and ensures they work in
restricted environments (e.g. offline or without Git), while still
supporting live API calls when keys are provided.  Future additions
should bump the version number in both the filename and docstring to
preserve traceability.

### Advanced helpers (zamida_helpers_v0_02.py)

An updated helper file ``zamida_helpers_v0_02.py`` builds on the v0.01
module with utilities for network testing, snapshot management and context
watching.  Its main features are:

- ``is_network_available()`` – perform a lightweight HTTP GET to
  determine if outbound network requests are permitted.
- ``update_snapshots()`` – regenerate ``context_snapshot`` and
  ``code_snapshot`` files for a given project root.
- ``watch_and_update()`` – monitor Python and Markdown files for
  modifications and automatically refresh snapshots when changes are
  detected.

Import these functions from ``zamida_helpers_v0_02`` when you need
runtime monitoring or to verify network connectivity.

### Bullet‑proof backup support

To ensure that your work is never lost, a new backup routine is included in
``backup_manager.py``.  This helper script creates timestamped, versioned
archives of your entire ZDownloadManager project.  Run it from the root of
your project as follows:

```
python backup_manager.py --project-dir . --output-dir backups
```

The script will produce a ZIP file named ``ZDownloadManager_<version>_<timestamp>.zip``
in the ``backups/`` directory, excluding the backup directory itself to
prevent nested archives.  You can limit the number of retained backups via
the optional ``--max-backups`` argument (e.g. ``--max-backups 5`` keeps only
the five most recent archives).  See the docstring in ``backup_manager.py``
for additional details and future enhancement suggestions.

### Memory graph and dependency analysis

Agents can benefit from a higher‑level view of the codebase.  The
``memory_graph_manager.py`` module defines a lightweight ``MemoryGraph``
and ``Node`` abstraction similar to HelixHyper’s graph engine.  Nodes
represent files and edges represent ``imports`` relationships between
files.  The ``scripts/build_memory_graph.py`` helper reads
``context_snapshot.json`` and writes ``memory_graph.json``.  You can
load the resulting graph in Python to analyse dependency chains or
identify modules with many dependents::

    python scripts/build_memory_graph.py --context context_snapshot.json --output memory_graph.json

In addition to constructing the graph, the API exposes analysis helpers:

- ``compute_strongly_connected_components(graph)`` computes the
  strongly connected components (cycles) in the graph.  Components
  with more than one node highlight mutually dependent modules and can
  indicate places where refactoring is beneficial.
- ``find_most_dependent_nodes(graph, top_n=5)`` calculates inbound
  dependency counts and returns the most heavily depended‑on files.
  These central modules are often high‑value targets for optimisation or
  API stabilisation.

### Plugin architecture

ZDownloadManager now supports a simple plugin mechanism to extend
functionality without modifying the core.  Create a ``plugins/``
directory at the project root and drop Python files into it.  Each
plugin can optionally define a ``register()`` function, which will be
called when the plugin is loaded.  Plugins may also expose
``on_<event>()`` hooks (e.g. ``on_start()`` or ``on_download_complete()``).
The plugin loader collects these hooks into a global ``plugin_hooks``
dictionary for later invocation by the application.  Use
``from zdownloadmanager.core.plugin_manager import load_plugins`` and
call ``load_plugins()`` at startup to discover and register
extensions.  Plugins might implement custom download post‑processors,
new CLI commands, or integration hooks.  Any import errors are
reported but do not halt the loading of other plugins.

### Continuous integration and tests

Quality assurance is enforced via unit tests located in
``ZDownloadManager/tests``.  These cover critical functionality such
as the backup manager, snapshot generation, memory graph building and
the plugin loader.  A GitHub Actions workflow
(``.github/workflows/python-test.yml``) is provided to automatically
run tests on pushes and pull requests.  To run the tests locally, execute::

    python -m unittest discover -s ZDownloadManager/tests -p 'test_*.py'

You are encouraged to add more tests as you extend the system.  The
continuous integration pipeline ensures that new contributions do not
break existing features.

### Self‑engineering improvements

The ``scripts/self_engineer.py`` tool can now create GitHub issues
automatically.  Pass ``--create-issue`` along with ``--repo`` (in
``owner/repo`` format) and ensure that the ``GITHUB_TOKEN`` environment
variable contains a personal access token with repository scope.  The
suggestion generated by the script will be used as the issue body, and
you can customise the title via ``--issue-title``.  This feature allows
the system to propose and track improvements in a collaborative
workflow.

### Logging configuration

Core modules now emit messages via Python’s standard ``logging``
module.  You can configure logging behaviour by setting handlers and
levels in your own scripts.  A future enhancement could add a
``logging_config.py`` file with a default configuration for the
application.