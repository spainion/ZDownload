#!/usr/bin/env python
"""List available models from OpenRouter.

This helper script prints the JSON response from the OpenRouter models
endpoint. It requires the environment variable ``OPENROUTER_API_KEY`` to be
set to a valid API key. The script intentionally keeps its footprint
small and does not depend on any of the rest of the package.
"""
from __future__ import annotations

import json
import os
import sys
import requests


def main() -> None:
    key = os.environ.get("OPENROUTER_API_KEY")
    if not key:
        raise SystemExit("OPENROUTER_API_KEY not set")
    try:
        resp = requests.get(
            "https://openrouter.ai/api/v1/models",
            headers={"Authorization": f"Bearer {key}"},
            timeout=10,
        )
    except Exception as e:
        print(f"Failed to retrieve models: {e}", file=sys.stderr)
        sys.exit(1)
    if resp.status_code != 200:
        print(f"Failed to retrieve models: {resp.status_code} {resp.text}", file=sys.stderr)
        sys.exit(1)
    print(json.dumps(resp.json(), indent=2))


if __name__ == "__main__":
    main()