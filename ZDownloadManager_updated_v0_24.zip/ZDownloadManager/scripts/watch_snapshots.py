#!/usr/bin/env python3
"""Watch for file changes and regenerate snapshots on the fly.

This script monitors the project directory for modifications to Python
and Markdown files.  When a change is detected it regenerates both
``context_snapshot.*`` and ``code_snapshot.*`` using the helper
functions in ``zamida_helpers_v0_02``.  It is intended to run in the
background during development to keep the context used by AI agents up
to date without manual intervention.

Example::

    python scripts/watch_snapshots.py --root . --interval 5

The watcher polls the filesystem every ``interval`` seconds (default 5)
and triggers snapshot updates when modifications are detected.

Note
----
This implementation uses a polling loop rather than an event-based
watcher to avoid external dependencies.  It should be sufficient for
development environments where changes are infrequent.  For high
frequency or production usage consider integrating a library such
as ``watchdog`` for efficient file watching.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from zamida_helpers_v0_02 import watch_and_update


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=Path("."),
        help="Directory to watch (default: current directory)",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=5.0,
        help="Seconds between polls (default: 5)",
    )
    args = parser.parse_args()
    print(f"Watching {args.root} every {args.interval} seconds for changes...")
    try:
        watch_and_update(args.root, interval=args.interval)
    except KeyboardInterrupt:
        print("Stopped watching.")


if __name__ == "__main__":
    main()