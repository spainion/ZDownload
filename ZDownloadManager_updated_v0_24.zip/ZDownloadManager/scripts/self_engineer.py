#!/usr/bin/env python3
"""
Generate improvement suggestions for the ZDownloadManager project.

This script uses the existing suggestion system to ask an AI model how to
improve the codebase.  It can be run from the command line and will write
the generated advice into a file for later review.  If the network is
disabled or the API key is missing, it falls back to an offline search over
the context snapshot.

Example usage::

    python scripts/self_engineer.py --question "How can I optimise the download
    manager for large files?" --output suggestions.md

The question may reference specific modules or functions.  The output file
will contain the returned suggestion or a note if no suggestion was
available.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from zdownloadmanager.core.config import Config
from zdownloadmanager.core.suggestions import get_suggestion

import os
import requests


def create_github_issue(repo: str, title: str, body: str, token: str | None = None) -> None:
    """Create a GitHub issue on the specified repository.

    Parameters
    ----------
    repo : str
        Repository in ``owner/repo`` format.
    title : str
        The issue title.
    body : str
        The issue body/description.
    token : str or None
        GitHub personal access token with ``repo`` scope.  If ``None``,
        the ``GITHUB_TOKEN`` environment variable is used.

    Notes
    -----
    This helper uses the GitHub REST API.  It makes a single POST
    request and prints the result.  In offline or restricted
    environments the call will fail silently.
    """
    if token is None:
        token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("GitHub token not provided; cannot create issue.")
        return
    url = f"https://api.github.com/repos/{repo}/issues"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "ZDownloadManager/self_engineer",
    }
    payload = {"title": title, "body": body}
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=10)
        if resp.status_code == 201:
            issue_url = resp.json().get("html_url")
            print(f"Issue created: {issue_url}")
        else:
            print(f"Failed to create issue: {resp.status_code} {resp.text}")
    except Exception as e:
        print(f"Error creating issue: {e}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--question",
        type=str,
        default="Suggest improvements and new helper modules for the ZDownloadManager project.",
        help="The question to pose to the AI suggestion system",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("self_engineering_suggestion.md"),
        help="Path to save the suggestion (default: self_engineering_suggestion.md)",
    )
    parser.add_argument(
        "--create-issue",
        action="store_true",
        help="Create a GitHub issue with the suggestion content",
    )
    parser.add_argument(
        "--repo",
        type=str,
        default=None,
        help="GitHub repository in owner/repo format (required when using --create-issue)",
    )
    parser.add_argument(
        "--issue-title",
        type=str,
        default=None,
        help="Title for the GitHub issue; defaults to the first 50 characters of the question",
    )
    args = parser.parse_args()

    cfg = Config()
    suggestion = get_suggestion(cfg, args.question)
    if suggestion:
        content = suggestion
    else:
        content = "No suggestion could be generated. Check your network settings and API keys."
    args.output.write_text(content, encoding="utf-8")
    print(f"Suggestion saved to {args.output}")
    # Optionally create a GitHub issue if requested
    if args.create_issue:
        if not args.repo:
            print("--repo must be provided when using --create-issue")
        else:
            title = args.issue_title or args.question[:50]
            create_github_issue(args.repo, title, content)


if __name__ == "__main__":
    main()