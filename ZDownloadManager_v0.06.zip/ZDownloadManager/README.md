ZDownloadManager
=================

ZDownloadManager is a cross‑platform download manager and smart file organizer designed to run on
Windows and macOS. It features:

* **Resumable downloads:** Download files from one or more mirrors. If the connection is
  interrupted the manager will use HTTP Range requests to resume from exactly where
  it left off. When Range support is unavailable, it falls back to a sequential
  streaming mode. This technique is part of the HTTP specification and allows
  partial content retrieval【939634575679302†L24-L29】.
* **Byte‑level verification:** Each download is split into pieces and hashed
  using SHA‑256. When resuming, pieces are validated on disk and requeued if
  corrupt.
* **Multi‑source support:** Supply a list of mirror URLs separated by commas. If one
  server fails to deliver a piece the next mirror is tried automatically.
* **Library manager:** Once a download completes it is automatically
  organised into logical categories (programs, packages, other files) and indexed in
  a library. Categories and tags can be defined and adjusted by the user.
* **Smart renaming:** Filenames are normalised by replacing underscores and
  hyphens with spaces【224425605480187†L54-L82】 and heuristically inserting a `v`
  prefix before version numbers. This produces consistently readable names (for
  example `my-file-1.0.zip` becomes `my file v1.0.zip`).
* **Right‑click actions:** The library view exposes a configurable context menu.
  Actions are defined in a JSON file and can launch external programs, run
  scripts or display computed information. A built‑in editor allows editing
  the actions from within the application.
* **Chrome integration:** A native messaging host and a small MV3 extension allow
  Chrome/Chromium to hand off downloads to ZDownloadManager. To install the
  native host, run the appropriate script in `install/` and load the
  extension from `chrome_extension/`.

Getting Started
---------------

Install the dependencies (at minimum `requests` and `tqdm` for the CLI or
`PyQt5` for the graphical interface) and run the main module:

```bash
pip install -r requirements.txt

# Start the graphical application
python -m zdownloadmanager.ui.main_window

# Or use the CLI
zdm https://example.com/file.iso -o /path/to/file.iso --mirrors https://mirror1.com/file.iso,https://mirror2.com/file.iso
```

The first time you run the GUI, a configuration directory is created in a
platform‑appropriate location. You can customise library roots, piece size,
concurrency, categories and actions via the **Config** dialog.

Packaging & Distribution
------------------------

To produce a stand‑alone build for Windows or macOS you can use
PyInstaller. The project intentionally avoids external native dependencies to
ease packaging. Building the installer is left to distribution tools like
Inno Setup (Windows) or a macOS `pkg`. The `chrome_extension/` directory
contains an example MV3 extension and the `install/` folder has scripts to
install the native messaging host. See their individual readme comments for
details.

License
-------

This software is distributed as free software. Feel free to modify and
redistribute it under the terms of the MIT license.