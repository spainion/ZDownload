"""Command line interface for ZDownloadManager.

This script provides a basic CLI for downloading files using the segmented
downloader and then organising them into the library. It accepts a primary
URL and an optional comma‑separated list of mirrors. It can be used as a
simple default download handler or invoked by the Chrome bridge.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from .core.config import Config
from .core.downloader import SegmentedDownloader, DownloadError
from .core.organizer import Organizer


def main(argv: Optional[list[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Download files with resume and organise them.")
    parser.add_argument("url", help="Primary download URL")
    parser.add_argument("-o", "--output", dest="output", default=None, help="Destination file path")
    parser.add_argument("--mirrors", dest="mirrors", default="", help="Comma separated list of mirror URLs")
    parser.add_argument("--piece", dest="piece_size", type=int, default=None, help="Piece size in bytes (default 4 MiB)")
    parser.add_argument("--conc", dest="concurrency", type=int, default=None, help="Number of concurrent pieces (default 4)")
    args = parser.parse_args(argv)

    urls = [args.url] + [u for u in args.mirrors.split(",") if u.strip()]
    dest = Path(args.output) if args.output else Path(Path(args.url).name)
    cfg = Config()
    piece_size = args.piece_size or cfg.piece_size
    concurrency = args.concurrency or cfg.concurrency
    try:
        dl = SegmentedDownloader(urls, dest, piece_size=piece_size, concurrency=concurrency)
        dl.download()
    except DownloadError as e:
        print(f"Download failed: {e}")
        return
    # Before organising the downloaded file into the library, verify that the
    # file has been completely downloaded. This helps avoid moving partial
    # downloads into the library (which can happen if the process was killed
    # mid‑download). We check the expected file size stored in the manifest
    # against the actual size on disk.
    expected_size = None
    try:
        # dl.conn may be closed at this point, so re‑open to fetch meta
        expected_size_str = dl._get_meta("file_size") if hasattr(dl, '_get_meta') else None
        if expected_size_str and expected_size_str.isdigit():
            expected_size = int(expected_size_str)
    except Exception:
        expected_size = None
    try:
        actual_size = dest.stat().st_size
    except Exception:
        actual_size = None
    # If we know the expected size and the file on disk is smaller, skip
    # organisation and inform the user.
    if expected_size is not None and actual_size is not None and actual_size < expected_size:
        print(
            f"Download incomplete: expected {expected_size} bytes, got {actual_size} bytes. "
            f"File remains at {dest}."
        )
        return
    # Organise into library
    organizer = Organizer(cfg)
    try:
        new_path = organizer.organise(dest)
        print(f"Downloaded and stored at: {new_path}")
    except Exception as e:
        # If organisation fails, report and leave the file where it is
        print(f"Failed to organise file: {e}")
        print(f"File remains at: {dest}")


if __name__ == "__main__":
    main()