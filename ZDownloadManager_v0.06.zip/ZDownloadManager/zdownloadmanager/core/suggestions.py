"""Integration with OpenRouter to provide file suggestions.

This module offers a simple wrapper around the OpenRouter chat completion
endpoint. It is used to retrieve contextual information about files (e.g.
descriptions of programs) by asking an AI model. The API key and whether
suggestions should be enabled are configured in ``Config``. If the key is
missing or suggestions are disabled, the functions return ``None``.
"""
from __future__ import annotations

import json
from typing import Optional

import requests

from .config import Config


def get_suggestion(config: Config, question: str) -> Optional[str]:
    """Ask OpenRouter for a suggestion about ``question``.

    Returns a string if a suggestion was retrieved, otherwise ``None``.
    """
    if not config.suggestions_enabled:
        return None
    api_key = config.openrouter_api_key
    if not api_key:
        return None
    try:
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": "openai/gpt-4o",
            "messages": [
                {"role": "user", "content": question}
            ],
            "stream": False,
        }
        resp = requests.post(url, headers=headers, json=payload, timeout=30)
        if resp.status_code != 200:
            return None
        data = resp.json()
        choices = data.get("choices") or []
        if not choices:
            return None
        message = choices[0].get("message", {})
        return message.get("content")
    except Exception:
        # On any error, fail silently
        return None